<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "guesthouse");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$guests = mysqli_real_escape_string($link, $_REQUEST['guests']);
$nights = mysqli_real_escape_string($link, $_REQUEST['nights']);
$ach= mysqli_real_escape_string($link, $_REQUEST['ach']);

$ccnum = mysqli_real_escape_string($link, $_REQUEST['ccnum']);

$expmonth = mysqli_real_escape_string($link, $_REQUEST['expmonth']);
$expyear = mysqli_real_escape_string($link, $_REQUEST['expyear']);
$cvv = mysqli_real_escape_string($link, $_REQUEST['cvv']);
 
 
// attempt insert query execution

$sql = "INSERT INTO guest (guests, nights, ach, ccnum,expmonth,expyear, cvv) VALUES ('$guests','$nights','$ach','$ccnum','$expmonth','$expyear','$cvv')";

if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>